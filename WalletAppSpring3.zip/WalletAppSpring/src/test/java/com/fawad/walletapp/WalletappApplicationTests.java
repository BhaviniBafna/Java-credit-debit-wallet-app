package com.fawad.walletapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalletappApplicationTests {

    @Test
    void contextLoads() {
    }

}
